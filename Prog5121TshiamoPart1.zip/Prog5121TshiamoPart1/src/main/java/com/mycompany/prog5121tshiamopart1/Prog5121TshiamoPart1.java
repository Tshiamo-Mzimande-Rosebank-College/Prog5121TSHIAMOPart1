package com.mycompany.prog5121tshiamopart1;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;

// class for storing user data
class UserAccount {
    private String username;
    private String passwordHash;
    private String cellNumber;
    private byte[] saltValue;
    private String first;
    private String last;
    
    // constructor
    public UserAccount(String username, String password, String cellNumber, String first, String last){
        this.username = username;
        this.saltValue = makeSalt();
        this.passwordHash = encode(password, saltValue);
        this.cellNumber = cellNumber;
        this.first = first;
        this.last = last;
    }
    
    // getters
    public String getUsername(){ return username; }
    public String getFirst(){ return first; }
    public String getLast(){ return last; }
    
    // check if password matches
    public boolean checkPass(String entered){
        return this.passwordHash.equals(encode(entered, this.saltValue));
    }
    
    // check username format
    public static boolean validUser(String name){
        if(name == null) return false;
        return name.contains("_") && name.length() <= 5;
    }
    
    // check password strength
    public static boolean strongPass(String pass){
        if(pass == null || pass.length() < 8) return false;
        
        boolean hasBig = false;
        boolean hasNum = false;
        boolean hasSym = false;
        String symbols = "!@#$%^&*()_+=-[]{}|;:'\",.<>?/~`";
        
        for(int i = 0; i < pass.length(); i++){
            char ch = pass.charAt(i);
            if(Character.isUpperCase(ch)) hasBig = true;
            if(Character.isDigit(ch)) hasNum = true;
            if(symbols.indexOf(ch) >= 0) hasSym = true;
        }
        return hasBig && hasNum && hasSym;
    }
    
    // validate SA phone number
    public static boolean goodPhone(String phone){
        if(phone == null) return false;
        String pattern = "^\\+27[0-9]{9}$";
        return Pattern.matches(pattern, phone);
    }
    
    // hash password with SHA-256
    private String encode(String password, byte[] salt){
        try{
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);
            byte[] hash = md.digest(password.getBytes());
            StringBuilder hex = new StringBuilder();
            for(byte b : hash){
                hex.append(String.format("%02x", b));
            }
            return hex.toString();
        } catch(NoSuchAlgorithmException e){
            throw new RuntimeException("error", e);
        }
    }
    
    // generate random salt
    private byte[] makeSalt(){
        SecureRandom rand = new SecureRandom();
        byte[] salt = new byte[16];
        rand.nextBytes(salt);
        return salt;
    }
}

public class Prog5121TshiamoPart1 {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        ArrayList<UserAccount> allUsers = new ArrayList<>();
        
        System.out.println("\n=================================");
        System.out.println("      WELCOME TSHIAMO'S APP");
        System.out.println("=================================");
        
        while(true){
            System.out.println("\n[1] Create Account");
            System.out.println("[2] Login");
            System.out.println("[3] Quit");
            System.out.print("Select: ");
            
            int option = 0;
            // handle wrong input
            try{
                option = scan.nextInt();
                scan.nextLine();
            } catch(Exception e){
                System.out.println("Type number only!");
                scan.nextLine();
                continue;
            }
            
            if(option == 1){
                System.out.println("\n>>> REGISTRATION <<<");
                
                System.out.print("First name: ");
                String first = scan.nextLine();
                
                System.out.print("Last name: ");
                String last = scan.nextLine();
                
                System.out.print("Username (needs _ and max 5 letters): ");
                String user = scan.nextLine();
                
                // validate username
                if(!UserAccount.validUser(user)){
                    System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
                    continue;
                }
                System.out.println("Username successfully captured!");
                
                System.out.print("Password (8+ chars, uppercase, number, special): ");
                String pass = scan.nextLine();
                
                // validate password
                if(!UserAccount.strongPass(pass)){
                    System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
                    continue;
                }
                System.out.println("Password successfully captured!");
                
                System.out.print("Cell number (+27 then 9 digits): ");
                String phone = scan.nextLine();
                
                // validate phone
                if(!UserAccount.goodPhone(phone)){
                    System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
                    continue;
                }
                System.out.println("Cell phone number successfully added!");
                
                // check for duplicate
                boolean exists = false;
                for(UserAccount u : allUsers){
                    if(u.getUsername().equals(user)){
                        exists = true;
                        break;
                    }
                }
                
                if(exists){
                    System.out.println("Username already taken!");
                    continue;
                }
                
                // save user
                allUsers.add(new UserAccount(user, pass, phone, first, last));
                System.out.println("\n*** ACCOUNT CREATED ***");
                System.out.println("Hi " + user + "! You can login now.\n");
                
                // auto login after registration
                System.out.println("--- LOGIN PAGE ---");
                System.out.print("Username: ");
                String tryUser = scan.nextLine();
                System.out.print("Password: ");
                String tryPass = scan.nextLine();
                
                boolean logged = false;
                for(UserAccount u : allUsers){
                    if(u.getUsername().equals(tryUser) && u.checkPass(tryPass)){
                        System.out.println("\nWelcome " + u.getFirst() + ", " + u.getLast() + " it is great to see you again.");
                        logged = true;
                        break;
                    }
                }
                
                if(!logged){
                    System.out.println("\nUsername or password incorrect, please try again.");
                }
            }
            else if(option == 2){
                // check if any users exist
                if(allUsers.isEmpty()){
                    System.out.println("\nNo users yet. Register first!");
                    continue;
                }
                
                System.out.println("\n--- LOGIN PAGE ---");
                System.out.print("Username: ");
                String tryUser = scan.nextLine();
                System.out.print("Password: ");
                String tryPass = scan.nextLine();
                
                // find matching user
                boolean logged = false;
                for(UserAccount u : allUsers){
                    if(u.getUsername().equals(tryUser) && u.checkPass(tryPass)){
                        System.out.println("\nWelcome " + u.getFirst() + ", " + u.getLast() + " it is great to see you again.");
                        logged = true;
                        break;
                    }
                }
                
                if(!logged){
                    System.out.println("\nUsername or password incorrect, please try again.");
                }
            }
            else if(option == 3){
                System.out.println("\nGOODBYE!");
                break;
            }
            else{
                System.out.println("\nInvalid! Choose 1,2 or 3.");
            }
        }
        scan.close();
    }
}