/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.prog5121tshiamopart1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author moarabismacbook
 */
public class UserAccountTest {
    
    public UserAccountTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getUsername method, of class UserAccount.
     */
    @Test
    public void testGetUsername() {
        System.out.println("getUsername");
        UserAccount instance = null;
        String expResult = "";
        String result = instance.getUsername();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getFirst method, of class UserAccount.
     */
    @Test
    public void testGetFirst() {
        System.out.println("getFirst");
        UserAccount instance = null;
        String expResult = "";
        String result = instance.getFirst();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLast method, of class UserAccount.
     */
    @Test
    public void testGetLast() {
        System.out.println("getLast");
        UserAccount instance = null;
        String expResult = "";
        String result = instance.getLast();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkPass method, of class UserAccount.
     */
    @Test
    public void testCheckPass() {
        System.out.println("checkPass");
        String entered = "";
        UserAccount instance = null;
        boolean expResult = false;
        boolean result = instance.checkPass(entered);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of validUser method, of class UserAccount.
     */
    @Test
    public void testValidUser() {
        System.out.println("validUser");
        String name = "";
        boolean expResult = false;
        boolean result = UserAccount.validUser(name);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of strongPass method, of class UserAccount.
     */
    @Test
    public void testStrongPass() {
        System.out.println("strongPass");
        String pass = "";
        boolean expResult = false;
        boolean result = UserAccount.strongPass(pass);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of goodPhone method, of class UserAccount.
     */
    @Test
    public void testGoodPhone() {
        System.out.println("goodPhone");
        String phone = "";
        boolean expResult = false;
        boolean result = UserAccount.goodPhone(phone);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
